# XA AJEET

XA AJEET is a public resource website template.

## Apne resources kaise add karein

`script.js` file kholo aur `resources` ke andar items add karo:

```js
{
  title: "My XMP Pack",
  type: "xmp",
  description: "Lightroom XMP preset pack.",
  url: "https://your-link.com",
  icon: "🎨"
}
```

Available categories:
- xmp
- cc
- packs
- apps
- photos
- videos

`url` mein apni file/download/link ka URL daal sakte ho.

## Important
Ye version static website hai. Ismein visitors ko direct website se files upload karwane ka system nahi hai. Owner ke resources ko links ke through publish kiya ja sakta hai.
